import { useRef } from 'react'
import Lenis from 'lenis'
import { Preloader } from './preloader/Preloader'
import { Hero } from './Hero'
import { useReducedMotion } from './preloader/useReducedMotion'
import './app.css'

/**
 * Lab harness.
 *
 * The <Preloader> overlays the whole page. The <Hero> (and the sections beneath
 * it) live underneath, revealed when the preloader hands off:
 *   - onReveal   -> kick the hero entrance so it clips in WITH the overlay wipe
 *   - onComplete -> overlay is gone; initialize Lenis smooth scroll
 *
 * This composition is deliberately thin: the preloader stays a self-contained
 * widget, and the host owns page concerns (hero + scrolling).
 */
export default function App() {
  const reduced = useReducedMotion()
  const heroRef = useRef(null)
  const lenisRef = useRef(null)

  const handleReveal = () => {
    heroRef.current?.animateIn()
  }

  const handleComplete = () => {
    // Respect reduced motion: skip smooth-scroll inertia entirely.
    if (reduced || lenisRef.current) return
    const lenis = new Lenis({
      duration: 1.1,
      smoothWheel: true,
      lerp: 0.1,
    })
    lenisRef.current = lenis
    const raf = (time) => {
      lenis.raf(time)
      requestAnimationFrame(raf)
    }
    requestAnimationFrame(raf)
  }

  return (
    <>
      <Preloader onReveal={handleReveal} onComplete={handleComplete} />

      <main>
        <Hero ref={heroRef} />

        {/* A second section purely so smooth scroll is demonstrable in the lab. */}
        <section className="lab-section">
          <div className="lab-section-inner">
            <h2>Custom builds, lead gen, chatbots.</h2>
            <p>
              This placeholder section exists only so you can feel the Lenis
              smooth-scroll after the reveal. Scroll up and down &mdash; the
              preloader above is the deliverable; everything here is scaffolding
              for the lab.
            </p>
          </div>
        </section>
      </main>
    </>
  )
}
