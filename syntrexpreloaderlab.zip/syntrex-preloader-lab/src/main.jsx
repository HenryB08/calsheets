import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.jsx'

// NOTE: StrictMode intentionally omitted. Its dev-only double-invoke of
// effects double-mounts the WebGL canvas / GSAP timelines / Lenis instance,
// which is noisy for a 3D + animation prototype. Re-enable if you prefer.
createRoot(document.getElementById('root')).render(<App />)
