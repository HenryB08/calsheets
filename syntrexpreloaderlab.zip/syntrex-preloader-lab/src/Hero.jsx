import { forwardRef, useImperativeHandle, useRef } from 'react'
import gsap from 'gsap'
import { useReducedMotion } from './preloader/useReducedMotion'
import './hero.css'

/**
 * The hero that clips into view once the preloader reveals. It exposes an
 * imperative `animateIn()` so the host can fire the entrance in sync with the
 * preloader's overlay wipe.
 */
export const Hero = forwardRef(function Hero(_, ref) {
  const reduced = useReducedMotion()
  const root = useRef(null)
  const eyebrow = useRef(null)
  const headline = useRef(null)
  const subhead = useRef(null)
  const actions = useRef(null)

  useImperativeHandle(ref, () => ({
    animateIn() {
      if (reduced) {
        gsap.set([eyebrow.current, headline.current, subhead.current, actions.current], {
          autoAlpha: 1,
          y: 0,
        })
        gsap.set(root.current, { clipPath: 'inset(0 0 0 0)' })
        return
      }

      const tl = gsap.timeline({ defaults: { ease: 'power3.out' } })
      tl.fromTo(
        root.current,
        { clipPath: 'inset(100% 0 0 0)' },
        { clipPath: 'inset(0% 0 0 0)', duration: 1.1, ease: 'power3.inOut' },
        0,
      )
      tl.fromTo(
        [eyebrow.current, headline.current, subhead.current, actions.current],
        { autoAlpha: 0, y: 40 },
        { autoAlpha: 1, y: 0, duration: 0.9, stagger: 0.12 },
        0.35,
      )
    },
  }))

  return (
    <section ref={root} className="hero">
      <div className="hero-inner">
        <p ref={eyebrow} className="hero-eyebrow">
          <span className="hero-dot" /> SYNTREX · AI AUTOMATION AGENCY
        </p>

        <h1 ref={headline} className="hero-headline">
          We build custom AI that handles your business&rsquo;s{' '}
          <span className="accent">busywork for you.</span>
        </h1>

        <p ref={subhead} className="hero-subhead">
          From lead gen to chatbots to custom internal tools — we design,
          build, and run the automations so your team doesn&rsquo;t have to.
        </p>

        <div ref={actions} className="hero-actions">
          <a className="btn btn-primary" href="#">
            Book a call
          </a>
          <a className="btn btn-ghost" href="#">
            See what we build
          </a>
        </div>
      </div>

      <div className="hero-scrollhint">scroll ↓</div>
    </section>
  )
})
