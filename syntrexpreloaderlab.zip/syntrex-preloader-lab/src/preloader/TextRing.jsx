import { useMemo, useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import { Text } from '@react-three/drei'

// Poppins (semibold) for the 3D ring text. Troika loads this at runtime and
// falls back to its bundled sans if the fetch fails, so the scene never breaks.
const POPPINS_URL =
  'https://cdn.jsdelivr.net/fontsource/fonts/poppins@latest/latin-600-normal.ttf'

const RING_TEXT = 'SYNTREX · AI AUTOMATION · CUSTOM BUILDS · LEAD GEN · CHATBOTS · '

/**
 * Marquee of brand text bent into a circle around the emblem. Each glyph is
 * placed at its own angle on a ring and rotated to sit tangent to the curve;
 * the whole group rotates slowly so the copy orbits the orb.
 */
export function TextRing({ radius = 3.1, reduced = false }) {
  const group = useRef()
  const chars = useMemo(() => RING_TEXT.split(''), [])
  const step = (Math.PI * 2) / chars.length

  useFrame((_, delta) => {
    if (reduced || !group.current) return
    group.current.rotation.z -= delta * 0.08
  })

  return (
    // Lay the ring flat-ish and tilt it so it reads as orbiting in 3D space.
    <group ref={group} rotation={[Math.PI / 2.35, 0, 0]}>
      {chars.map((char, i) => {
        const angle = i * step
        const x = Math.cos(angle) * radius
        const y = Math.sin(angle) * radius
        return (
          <Text
            key={i}
            font={POPPINS_URL}
            position={[x, y, 0]}
            // Rotate each glyph to be tangent to the circle, facing outward.
            rotation={[0, 0, angle - Math.PI / 2]}
            fontSize={0.26}
            letterSpacing={0.02}
            color="#cfe0ff"
            anchorX="center"
            anchorY="middle"
            outlineWidth={0}
          >
            {char}
          </Text>
        )
      })}
    </group>
  )
}
