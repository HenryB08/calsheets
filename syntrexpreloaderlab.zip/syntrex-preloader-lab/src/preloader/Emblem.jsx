import { MeshTransmissionMaterial, Text } from '@react-three/drei'

// Same Poppins face used by the orbiting ring, for the placeholder logo glyph.
const POPPINS_URL =
  'https://cdn.jsdelivr.net/fontsource/fonts/poppins@latest/latin-700-normal.ttf'

/**
 * The central glass orb plus the placeholder "S" logo suspended at its core.
 *
 * The sphere uses drei's MeshTransmissionMaterial so it refracts the blue-tinted
 * environment and the starfield behind it — reading as iridescent glass with
 * rainbow edges (driven by `chromaticAberration`).
 *
 * To swap in the real Syntrex mark: replace the <Text> "S" below with an
 * extruded SVG (e.g. drei's <Svg> or a custom ExtrudeGeometry) kept at roughly
 * the same scale/position so it still floats inside the orb.
 */
export function Emblem() {
  return (
    <group>
      {/* Glass orb */}
      <mesh>
        <sphereGeometry args={[1.15, 96, 96]} />
        <MeshTransmissionMaterial
          // refraction / glassiness
          transmission={1}
          ior={1.45}
          thickness={1.4}
          roughness={0.06}
          // rainbow edges
          chromaticAberration={0.6}
          anisotropicBlur={0.4}
          distortion={0.25}
          distortionScale={0.4}
          temporalDistortion={0.1}
          // a faint blue tint so it reads as Syntrex-branded glass
          attenuationColor="#2f6bff"
          attenuationDistance={2.4}
          color="#dce8ff"
          background={undefined}
          backside
          backsideThickness={0.6}
          samples={8}
          resolution={1024}
        />
      </mesh>

      {/* Placeholder "S" logo floating at the core — swap for real SVG later. */}
      <Text
        font={POPPINS_URL}
        position={[0, 0, 0]}
        fontSize={1.05}
        color="#ffffff"
        anchorX="center"
        anchorY="middle"
        fillOpacity={0.92}
        outlineWidth={0.012}
        outlineColor="#2f6bff"
        outlineOpacity={0.6}
      >
        S
      </Text>
    </group>
  )
}
