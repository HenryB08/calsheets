import { useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import { Environment, Lightformer, Float } from '@react-three/drei'
import * as THREE from 'three'
import { Emblem } from './Emblem'
import { Rings } from './Rings'
import { TextRing } from './TextRing'
import { Starfield } from './Starfield'
import { Effects } from './Effects'

/**
 * The full preloader 3D scene. Everything that should react to the mouse and to
 * the reveal transition lives under a single `emblemGroup`:
 *  - leans toward the cursor (lerped, so it feels weighty)
 *  - scales up during the GSAP reveal via the shared `reveal` ref
 */
export function Scene({ reduced = false, reveal }) {
  const emblemGroup = useRef()
  const target = useRef(new THREE.Vector2(0, 0))

  useFrame((state, delta) => {
    const g = emblemGroup.current
    if (!g) return

    // Lean toward the mouse. Disabled (and re-centered) under reduced motion.
    if (!reduced) {
      target.current.set(state.pointer.x, state.pointer.y)
    } else {
      target.current.set(0, 0)
    }
    const damp = 1 - Math.pow(0.001, delta) // frame-rate independent lerp
    g.rotation.y = THREE.MathUtils.lerp(g.rotation.y, target.current.x * 0.4, damp)
    g.rotation.x = THREE.MathUtils.lerp(g.rotation.x, -target.current.y * 0.3, damp)

    // Reveal: GSAP drives reveal.current.t from 0 -> 1 at load complete.
    const t = reveal?.current?.t ?? 0
    const s = 1 + t * 1.6 // scale up as it dissolves
    g.scale.setScalar(s)
    g.position.z = t * 2.2 // drift toward the camera
  })

  return (
    <>
      <color attach="background" args={['#060a16']} />
      <fog attach="fog" args={['#060a16', 8, 26]} />

      {/* Key + rim lighting tuned for dark glossy metal + glass */}
      <ambientLight intensity={0.35} />
      <directionalLight position={[5, 6, 4]} intensity={1.1} color="#cfe0ff" />
      <pointLight position={[-6, -3, -4]} intensity={40} color="#2f6bff" />

      {/* Blue-tinted studio environment: drives the orb's refraction + the
          rainbow edges, and the metal rings' reflections. */}
      <Environment resolution={512}>
        <Lightformer
          form="ring"
          intensity={2.2}
          color="#2f6bff"
          position={[0, 0, -5]}
          scale={[8, 8, 1]}
        />
        <Lightformer
          form="rect"
          intensity={1.6}
          color="#9fc0ff"
          position={[4, 3, 2]}
          scale={[4, 6, 1]}
        />
        <Lightformer
          form="rect"
          intensity={1.2}
          color="#ffffff"
          position={[-5, -2, 3]}
          scale={[3, 5, 1]}
        />
        <Lightformer
          form="circle"
          intensity={2}
          color="#1b3a8a"
          position={[0, 5, -2]}
          scale={[6, 6, 1]}
        />
      </Environment>

      <Starfield reduced={reduced} />

      <group ref={emblemGroup}>
        {/* A gentle idle bob on the orb + logo (off under reduced motion). */}
        <Float
          speed={reduced ? 0 : 1.2}
          rotationIntensity={reduced ? 0 : 0.15}
          floatIntensity={reduced ? 0 : 0.4}
        >
          <Emblem />
        </Float>
        <Rings reduced={reduced} />
        <TextRing reduced={reduced} />
      </group>

      <Effects reduced={reduced} />
    </>
  )
}
