import { useEffect, useLayoutEffect, useRef, useState } from 'react'
import { Canvas } from '@react-three/fiber'
import gsap from 'gsap'
import { Scene } from './Scene'
import { useReducedMotion } from './useReducedMotion'
import './preloader.css'

/**
 * Self-contained Syntrex preloader.
 *
 * Drops over any page as a fixed, full-screen overlay: shows the animated glass
 * emblem + a 00→100 loading counter, then plays a GSAP reveal (emblem scales &
 * fades, overlay clips away) to expose whatever sits beneath it.
 *
 * It owns no page-specific logic, so it can later be compiled into a drop-in
 * widget for the static site. The host coordinates via callbacks:
 *   - onReveal():   reveal transition has started — animate your hero in now.
 *   - onComplete(): overlay is gone & unmounting — safe to init smooth scroll.
 *
 * Props:
 *   loadMs    — simulated load duration (ms). Real apps can drive progress
 *               directly instead; see `progress` below.
 *   progress  — optional externally-controlled 0..100 value. When provided,
 *               the internal simulation is bypassed and the reveal fires when
 *               it reaches 100.
 */
export function Preloader({ onReveal, onComplete, loadMs = 3400, progress = null }) {
  const reduced = useReducedMotion()
  const [count, setCount] = useState(0)
  const [hidden, setHidden] = useState(false)

  const overlayRef = useRef(null)
  const canvasWrapRef = useRef(null)
  const uiRef = useRef(null)
  // Shared object the 3D scene reads each frame; GSAP animates `.t` 0 -> 1.
  const reveal = useRef({ t: 0 })
  const startedReveal = useRef(false)
  const onRevealRef = useRef(onReveal)
  const onCompleteRef = useRef(onComplete)
  onRevealRef.current = onReveal
  onCompleteRef.current = onComplete

  // --- Reveal transition -----------------------------------------------------
  const startReveal = () => {
    if (startedReveal.current) return
    startedReveal.current = true
    setCount(100)

    // Reduced motion: skip the cinematic dissolve, just fade out quickly.
    if (reduced) {
      onRevealRef.current?.()
      gsap.to(overlayRef.current, {
        autoAlpha: 0,
        duration: 0.4,
        ease: 'power1.out',
        onComplete: () => {
          setHidden(true)
          onCompleteRef.current?.()
        },
      })
      return
    }

    const tl = gsap.timeline()
    // 3D emblem scales up + drifts toward camera (read in Scene's useFrame).
    tl.to(reveal.current, { t: 1, duration: 1.5, ease: 'power2.in' }, 0)
    // Fade the loading UI immediately.
    tl.to(uiRef.current, { autoAlpha: 0, duration: 0.5, ease: 'power1.out' }, 0)
    // Emblem fades as it blows out.
    tl.to(
      canvasWrapRef.current,
      { autoAlpha: 0, duration: 0.9, ease: 'power2.in' },
      0.55,
    )
    // Hero starts clipping in underneath right about here.
    tl.add(() => onRevealRef.current?.(), 0.7)
    // Overlay wipes upward to expose the page beneath.
    tl.to(
      overlayRef.current,
      { clipPath: 'inset(0 0 100% 0)', duration: 1.0, ease: 'power3.inOut' },
      0.7,
    )
    tl.add(() => {
      setHidden(true)
      onCompleteRef.current?.()
    })
  }

  // --- Loading progress ------------------------------------------------------
  // Externally controlled progress takes over when provided.
  useEffect(() => {
    if (progress == null) return
    const clamped = Math.max(0, Math.min(100, progress))
    setCount(Math.round(clamped))
    if (clamped >= 100) startReveal()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [progress])

  // Otherwise simulate a load with a slightly organic ease.
  useEffect(() => {
    if (progress != null) return
    const proxy = { n: 0 }
    const tween = gsap.to(proxy, {
      n: 100,
      duration: reduced ? 0.9 : loadMs / 1000,
      ease: 'power1.inOut',
      onUpdate: () => setCount(Math.round(proxy.n)),
      onComplete: startReveal,
    })
    return () => tween.kill()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [progress, reduced])

  // Start the overlay clip from "fully visible".
  useLayoutEffect(() => {
    if (overlayRef.current) {
      overlayRef.current.style.clipPath = 'inset(0 0 0% 0)'
    }
  }, [])

  if (hidden) return null

  const padded = String(Math.min(100, count)).padStart(2, '0')

  return (
    <div ref={overlayRef} className="pl-overlay" aria-hidden="true">
      <div ref={canvasWrapRef} className="pl-canvas">
        <Canvas
          dpr={[1, 2]}
          gl={{ antialias: true, alpha: false, powerPreference: 'high-performance' }}
          camera={{ position: [0, 0, 7], fov: 45 }}
        >
          <Scene reduced={reduced} reveal={reveal} />
        </Canvas>
      </div>

      <div ref={uiRef} className="pl-ui">
        {/* top-left */}
        <a className="pl-brand" href="https://syntrexio.com">
          syntrexio.com
        </a>

        {/* bottom-left: counter + thin progress line */}
        <div className="pl-loader">
          <div className="pl-count">
            <span className="pl-count-num">{padded}</span>
            <span className="pl-count-pct">%</span>
          </div>
          <div className="pl-progress">
            <div
              className="pl-progress-fill"
              style={{ width: `${Math.min(100, count)}%` }}
            />
          </div>
          <div className="pl-loading-label">LOADING</div>
        </div>
      </div>
    </div>
  )
}
