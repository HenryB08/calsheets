import { useRef } from 'react'
import { useFrame } from '@react-three/fiber'

/**
 * Concentric "gear" rings (tori) in dark glossy metal that wrap the orb. Each
 * ring is tilted slightly off-axis and spins slowly; adjacent rings rotate in
 * alternating directions for a mechanical, interlocking feel.
 */
export function Rings({ reduced = false }) {
  // [radius, tubeThickness, tiltX, tiltY, spinSpeed]
  const config = [
    { r: 1.55, tube: 0.045, tilt: [0.5, 0.2, 0], speed: 0.25, segments: 64 },
    { r: 1.95, tube: 0.06, tilt: [-0.35, 0.4, 0.2], speed: -0.18, segments: 96 },
    { r: 2.4, tube: 0.035, tilt: [0.25, -0.3, -0.15], speed: 0.12, segments: 128 },
  ]

  return (
    <group>
      {config.map((c, i) => (
        <Ring key={i} {...c} reduced={reduced} />
      ))}
    </group>
  )
}

function Ring({ r, tube, tilt, speed, segments, reduced }) {
  const ref = useRef()

  useFrame((_, delta) => {
    if (reduced || !ref.current) return
    ref.current.rotation.z += delta * speed
  })

  return (
    <group rotation={tilt}>
      <mesh ref={ref}>
        <torusGeometry args={[r, tube, 24, segments]} />
        <meshStandardMaterial
          color="#0c1326"
          metalness={1}
          roughness={0.22}
          envMapIntensity={1.4}
        />
      </mesh>
    </group>
  )
}
