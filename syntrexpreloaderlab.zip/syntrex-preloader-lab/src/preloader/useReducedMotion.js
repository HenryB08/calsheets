import { useEffect, useState } from 'react'

/**
 * Tracks the user's `prefers-reduced-motion` setting and keeps it live if the
 * OS-level preference changes mid-session. Every animated piece of the
 * preloader reads this so we can degrade gracefully to a calm, near-static
 * experience when requested.
 */
export function useReducedMotion() {
  const [reduced, setReduced] = useState(() => {
    if (typeof window === 'undefined' || !window.matchMedia) return false
    return window.matchMedia('(prefers-reduced-motion: reduce)').matches
  })

  useEffect(() => {
    if (typeof window === 'undefined' || !window.matchMedia) return
    const mq = window.matchMedia('(prefers-reduced-motion: reduce)')
    const onChange = (e) => setReduced(e.matches)
    mq.addEventListener('change', onChange)
    return () => mq.removeEventListener('change', onChange)
  }, [])

  return reduced
}
