import {
  EffectComposer,
  Bloom,
  ChromaticAberration,
  DepthOfField,
  Vignette,
} from '@react-three/postprocessing'
import { BlendFunction } from 'postprocessing'
import * as THREE from 'three'

/**
 * Postprocessing stack that gives the emblem its glow and cinematic edge:
 * Bloom (the blue light bloom), a subtle full-frame chromatic aberration, and
 * a light depth-of-field so the orb pops against a soft background. A faint
 * vignette pulls focus to center.
 *
 * Under reduced-motion we drop DoF + aberration and keep only a gentle bloom.
 */
export function Effects({ reduced = false }) {
  if (reduced) {
    return (
      <EffectComposer multisampling={4}>
        <Bloom
          intensity={0.5}
          luminanceThreshold={0.25}
          luminanceSmoothing={0.4}
          mipmapBlur
        />
        <Vignette eskil={false} offset={0.25} darkness={0.7} />
      </EffectComposer>
    )
  }

  return (
    <EffectComposer multisampling={4}>
      <DepthOfField
        focusDistance={0.012}
        focalLength={0.04}
        bokehScale={2.2}
        height={480}
      />
      <Bloom
        intensity={0.9}
        luminanceThreshold={0.2}
        luminanceSmoothing={0.5}
        mipmapBlur
        radius={0.75}
      />
      <ChromaticAberration
        blendFunction={BlendFunction.NORMAL}
        offset={new THREE.Vector2(0.0009, 0.0012)}
        radialModulation={false}
        modulationOffset={0}
      />
      <Vignette eskil={false} offset={0.2} darkness={0.85} />
    </EffectComposer>
  )
}
